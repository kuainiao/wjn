#!/bin/bash
echo '                         
<?php $conn_str .= " user=postgres"; ?>' >> "./ext/pgsql/tests/config.inc"
psql -c 'create database test;' -U postgres